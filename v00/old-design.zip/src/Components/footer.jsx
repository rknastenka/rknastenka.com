

export default function Footer() {
    return (
        <footer> moretocome © 2025 ini </footer>
    );
}



