

export default function Writings() {
    return (
        <main>


<div>
            <h2> Who Am I ? </h2>
            <p>
                i wouldn't say i'm a web dev master nor a hardware grinder,
                i'm a jack of all trades, master of some. i'm a fast learner
                that's for sure, i do and act the way my curiosity leads me to,
            </p>
</div>

            <div>
            <h2> how I delight in serene melancholy </h2>
            <p>
                life is simple and full of happiness and welfare. If by any chance it seemed
                the opposite, trust me, there's only and only one reason for which life could seem miserable, which is
                obviously other people. We were born to build, to connect, to grow together hand in hand, but most of us
                got distracted by what society fooled them into. We make life miserable for one another; the only
                reason why we aren't all happy today is caused by another human, I wouldn't say I despise humans (I do)
                but I'd say most of the walking souls nowadays are merely retarded. But that's not what this topic is
                about, anyway
                we're here to talk about making your own happiness. As I mentioned earlier, life is full of joy and
                welfare,
                we just have to look for it. If not, you'll live in misery for the rest of your life. With the same two
                eyes
                I can see how life is fucked, and I can also see how beautiful it is. How I delight in serene melancholy
                means the joy I zip out of the messed up world.
            </p>
            </div>
            <h2>in a world where you wanna be everything, you must be defined as something </h2>
            <p>
                since the very first breath of maturity i took, i've wanted to ace everything, to be everything
                ,to know everything, and everyone. i was forever occupied with my own thoughts,
                with the palace of dreams i kept myself in. then i got that reality check that i must choose a path
                it's sad, ain't it. but it's reality one self must consent. i knew that for a fact and still refused to
                obey
                i know i might be wrong, it's a huge risk but i ain't letting myself in this herd. one argument ; which
                totally
                does make sense, says that companies and job market needs ppl whom are really good at one thing. it is
                so true
                but why should i oblige. one such self is me and me is refusing to obey to such nonsense.
                i'm not considering myself a polymath, but i may at some point be.
                for a human to be defined, one human has a one name, such and such each has a one x, no matter how many
                things
                you're actually good at, they're mostly all round about the same topic,
                for a long time in my life i thought i must be something. but do i...
                <br/>
                <br/>
            </p>

            <h2> Will I Ever Reach There </h2>
            <p>
                i've admired smart people, people who have done things, people who revolutised their fields, some are
                well known
                some aren't, but they all in one way or another contributed to the current life we've living right now.
                people who reached that are people who are willing to spend an unrealstic amount of time doing such
                thing or things.
                i have this amazing friend that keeps reminding me of this -your hardwwok will pay off, if not today
                then tomorroww, at the end
                it'll get you somewhere, not today maybe not tmrw as well but make sure that nothing goes for a waste.
                keep grinding to get what
                you've always dreamt of dear...
            </p>


            <h2> The Human Mankind cycle </h2>
            <p>
                We spend our lives chasing answers. One puzzle solved slips into the next, and along the way we collect
                obsessions; porn, cigarettes, social media, whatever dulls the ache for a minute. We gorge on
                information until the craving loses its grip, then we move on, convinced the next fix will finally
                silence the questions.
                We have been asking since childhood: Why is the sky blue? Why is “Dad” spelled D‑A‑D? Soon the questions
                aim at our friends, our lovers, the manager who frowns behind the desk, the stranger brushing past on
                the street. The interrogation never stops. We turn it on ourselves; our worth, our beauty, our
                God—looking for someone or something to shoulder the blame.
                And sometimes the weight feels lethal. One hardship too many and the mind whispers it would be easier to
                quit the whole experiment. Most of us have stood near that edge. Yet the very restlessness that drags us
                there also keeps us alive: the stubborn, infuriating need to know why, and what comes next.
            </p>

            <h2> Linkedin - Social Media </h2>
            <p>
                linkedin is the most self-humiliating human trafficking on earth. i just find it hilariously
                funny that we’re in an era where “dopamine detox”
                even exists, where we’re so spoiled now that we
                have to detox ourselves. i just find it really funny
                that we’re allowing ourselves to be in such a position.
                i hate all kinds of social media; i have nearly none.
                soon enough, i’ll be giving up on linkedin as well (after securing a job).

            </p>


            <h2> you're not lazy, you just need a reason. </h2>
            <p>
                updates soon...
            </p>

            <h2> The Art of Flow </h2>
            <p>
                soon...
            </p>

            <h2> what pisses me off about friends at collage </h2>
            <p>
                soon...
            </p>

            <h2> Collage Life At Jordan </h2>
            <p>
                soon...
            </p>
        </main>

    );
}