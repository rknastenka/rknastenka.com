## welcome to my blog

thank you for stalking me :P