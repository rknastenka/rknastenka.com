import Image from "next/image";

export default function Home() {
  return (
          <>

                <p>
                    <strong>
                        Hey stalker, welcome to my blog. Here you'll see a bunch of unscripted perceptions of mine,
                        i mostly post my thoughts and notions about different random topics
                        as i'm free as my thoughts allow me to be. get your cup of tea and enjoy reading
                        dear passenger.
                    </strong>
                </p>


                <br/>

                <p>
                    it's more about the time you spend understanding yourself
                    to get where you somehow specify your next step,
                    and you're barking the wrong tree if you believe it's social media
                    that's holding you back. when in fact, it's just you. during the past weeks,
                    the truth had dawned on me. i now avow the verity that has
                    always lain between my lines of complaint. we've all been in a lifelong run,
                    chasing answers and seeking to get somewhere we're not in. trying to do
                    everything whilst indeed doing nothing. yet i can't affirm my purpose,
                    but i somehow acknowledge my intents. hence, beyond my belief, which i may or may not achieve,
                    i wish to perceive more about the sky and moon and what's in between.
                </p>

                <br/>
                <br/>

                <div style={{
                    fontStyle: 'italic',
                    color: 'rgba(113,108,108,0.79)',
                    lineHeight: 1.5,
                    fontFamily: 'Constantia, monospace',
                }}
                >

                    <p>"I can never read all the books I want; I can never be all the
                        people I want and live all the lives I want. I can never train
                        myself in all the skills I want. And why do I want? I want to
                        live and feel all the shades, tones and variations of mental
                        and physical experience possible in my life. And I am horribly limited." </p>
                    <p style={{fontSize: '13px'}}>
                        <b> — Sylvia Plath, <cite>The Unabridged Journals of Sylvia Plath</cite>
                        </b></p>
                </div>

          </>
  );
}
