"use client";
import Link from "next/link";


export default function Navbar() {
  return (
    <header className="w-full backdrop-blur-sm">
      <div className="max-w-2xl mx-auto px-6 pt-4 lg:pt-8 sm:px-0 border-b border-zinc-700">
        <div className="flex h-24 items-center justify-between w-full">
          {/* Left: avatar + name + nav */}
          <div className="flex items-center gap-4 sm:gap-6">
            {/* Avatar */}
            <img
              src="/me.jpg"
              alt="Avatar"
              width={70}
              height={70}
              className="h-14 w-14 sm:h-16 sm:w-16 lg:h-18 lg:w-18 object-cover "
            />

            <div className="flex flex-col justify-between h-12 sm:h-14">
              {/* Name */}
              <div className="-mb-1 text-2xl sm:text-3xl lg:text-4xl font-medium leading-none font-headings">
                Bana Tawalbeh
              </div>
              
            {/* Navigation under name */}
            <nav className="flex items-center gap-2 sm:gap-3 text-xs leading-none font-bold">
            <Link href="https://github.com/itzbana" target="_blank" >GitHub</Link>
            <Link href="mailto:banabilalt@gmail.com" >Email</Link>
            <Link href="#" target="_blank" >Resume</Link>
            </nav>


            </div>
            
          </div>

          {/* Right: Links */}
          <nav className="flex flex-col gap-1 text-xs sm:text-sm leading-none">
                <Link href="#" >[About]</Link>
                <Link href="#" >[Projects]</Link>
                <Link href="#" >[Articles]</Link>
                <Link href="#" >[Links]</Link>
          </nav>

        </div>
      </div>
    </header>
  );
}

/*
  Notes:
  - Place your 72×72 avatar image at /public/avatar.png (or change the src).
  - The serif heading mimics the screenshot's typographic weight; adjust Tailwind font families
    in tailwind.config.js if you want a specific font.
  - Links, spacing, and subtle borders are tuned to match the reference look.
*/
